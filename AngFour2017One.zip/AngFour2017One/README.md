# Angular2TypeScriptASPNETCoreWebApp
An Angular 2 and TypeScript web application made with ASP.NET Core, for fun and curiosity

See the tutorial here : https://adrientorris.github.io/aspnet-core/how-setup-angular-2-typescript-project-visual-studio-2017.html