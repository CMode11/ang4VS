﻿import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-server',
    // template: '<p>The server component for me</p>'
    templateUrl: './server/server.component.html'
})
export class ServerComponent implements OnInit {

    constructor() {
        console.log('ServerComponent -> constructor');

    }

    ngOnInit() {
        console.log('ServerComponent -> ngOnInit');
    }

}